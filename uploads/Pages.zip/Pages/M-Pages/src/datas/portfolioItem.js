import { Animatable, Data } from 'framer'

export default Data([
  // 00
  {
    overlayOpacity: Animatable(0),
    captionOpacity: Animatable(0),
    captionRight: Animatable(0),
  },
  // 01
  {
    overlayOpacity: Animatable(0),
    captionOpacity: Animatable(0),
    captionRight: Animatable(0),
  },
  // 02
  {
    overlayOpacity: Animatable(0),
    captionOpacity: Animatable(0),
    captionRight: Animatable(0),
  },
  // 03
  {
    overlayOpacity: Animatable(0),
    captionOpacity: Animatable(0),
    captionRight: Animatable(0),
  },
])
