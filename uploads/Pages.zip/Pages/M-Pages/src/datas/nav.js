import { Animatable, Data } from 'framer'

const top = Animatable(0)

export default Data({
  top,
})
